[How to implement customized language translation on the PAC]

Following is an example for customizing the �Language� drop-down:

Download the 'Globalization.zip' file using the �Downloads� section of the 'About the PAC' page.  

Unzip the 'Globalization.zip' file directly to the "\\Hard Disk\Project\Web" folder on the PAC.
(Optionally you can unzip the file to a temporarily location on your own computer, then copy it to the SD Card later); 

Perform the modifications on its contents as described below. 

Once the contents of the unzipped Globalization template is modified and the two character country code is appended to the 
�Supplements� key of the �Language� section of the Webserver.exe.ini file�, and the PAC is restarted: the new language will 
become available to users whenever they connect to the web server via the �PAC Configuration Tool�. 


Perform the following steps to supplement or override the current set of languages:

For demonstration purposes we are going to change the the files to support "Swahili" (which has a two-character country code of "sw") 

1) Edit the '..\..\Globalization\SupportedLanguages.xml' file:

	Each of the first set of options in the file represents the word "Swahili"  translated into the respective language. 
	The languages are what gets displayed when the user clicks on the �Languages� drop-down in the 'PAC Configuration Tool'.
	
  a) Modify the value of each 'option' corresponding to the word "Swahili" in each language.
  
	For example:
	Replace "xx_in_en" to whatever the word "Swahili" is in English (i.e. <Languages id="en"><option id="xx">Swahili</option>); 
	Replace "xx_in_fr" to whatever the word "Swahili" is in French  (i.e. <Languages id="fr"><option id="xx">swahili</option>); 
	Replace "xx_in_de" to whatever the word "Swahili" is in German  (i.e. <Languages id="de"><option id="xx">Swahili</option>);  
	and so on...
	
  b) Modify the value of each 'option' in the group of options found under <Languages id="xx"> to whatever its value  
	 is in �Swahili�. 

	For example:
	Replace "en_in_xx" to whatever the word "English" is in Swahili (i.e. <option id="en">Kiingereza</option>); 
	Replace "fr_in_xx" to whatever the word "French"  is in Swahili (i.e. <option id="fr">Kifaransa</option>); 
	Replace "de_in_xx" to whatever the word "German"  is in Swahili (i.e. <option id="de">Ujerumani</option>);
	and so on...

  c) Replace all occurences of the two letter designation "xx" with �sw�,  (the language designation to be supplemented or 
	 overridden). 

	For example:
	Replace all instances of "xx" with "sw".

2)	Edit each template file in the '..\..\Globalization\Languages\xx\' folder beginning  with 'AboutInfo.xml' and ending with 
	'TucsonSettings.xml':

  a) Translate the value pertaining to each 'lbl' (short name for 'label') attribute and optionally the value of each 'ttp' 
	 ('tooltip') attribute2.

	For example (in the 'AboutInfo.xml' file):
	Replace the value "xxSeries" with "mfululizo" for the ModelNumberItem having the id="SERIES".
	Replace the value "xxSoftware" with "programu" for the ModelNumberItem having the id="SOFTWARE".
	Replace the value "xxVisualization" with "taswira" for the ModelNumberItem having the id="VISUALIZATION".
	and so on...
	
  b) Rename the parent folder containing the preceding set of files using the new two-letter country code.

	For example:
	Rename 'Globalization\Languages\xx\' to 'Globalization\Languages\sw\'.					
	
3)	Modify the internal contents of the 'Globalization\Languages\Flags\xx.png' file.

	For example:
	Using a graphical based editor, modify and save an image of the flag representing the new country.

4)	Change the name of the 'Globalization\Flags\xx.png' file using the new two letter country code:

	For example:
	Rename 'xx.png' to 'sw.png'  (i.e., 'Globalization\Flags\xx.png' to 'Globalization\Flags\sw.png').

5)	Edit the 'Webserver.exe.ini' file located in the "Hard Disk\Project\Web" folder (see Addendum 3 below) and append the 
	two-letter country code.

	For example:
	[LANGUAGES] 
	SUPPORTED=en,fr,de,sw

ADDENDNUM:

1	For the �customized� language(s) to be available for selection requires the SD-card to be inserted into the drive. 

2	Leaving the value of the ttp ('tooltip') attribute 'blank' results in whatever the valueis for the lbl ('label') attribute  
	to be used for the tooltip.

3	A default 'PAC Configuration Tool Ini file' is automatically created in the root directory of the SD-Card the first 
	time the PAC is started.

	If the PAC has not been previously started with the SD-Card inserted, you will need to download the 'PAC Configuration Tool Ini file' 
	to your PC; modify its contents as described above; then if necessary, 'manually' copy the file to the root directory of the SD-card.

